# Import necessary libraries
import pandas as pd
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Load the dataset
predict_rating_attraction_df = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Attractions/Dataset_Predict_Rating_attraction.csv")

# Chuyển giá trị từ 1.0 thành 1 trong cột 'User ID'
predict_rating_attraction_df['User ID'] = predict_rating_attraction_df['User ID'].astype(int)

# Sắp xếp DataFrame dựa trên cột 'User ID' tăng dần
predict_rating_attraction_df.sort_values(by='User ID', inplace=True)

def train_linear_regression_model_attraction():
    features_lr = predict_rating_attraction_df[['Attraction ID', 'User ID', 'Du thuyền 45 phút', 'Nhạc sống', 'Nước đóng chai', 'Trái cây', 'Bảo hiểm', 'Máy hát karaoke', 'Góc selfie', 'Buffet trưa tại nhà hàng', 'Đi cáp treo', 'Đón và trả khách', 'Dịch vụ hướng dẫn', 'Phương tiện đi lại khứ hồi', 'Vé vào các điểm tham quan', 'Lớp học nấu ăn', 'Đầu bếp nói', 'Dịch vụ hướng dẫn bằng tiếng anh', 'Cà phê', 'Thuê xe đạp']]
    ratings_lr = predict_rating_attraction_df['Ratings']

    X_train_lr, X_test_lr, y_train_lr, y_test_lr = train_test_split(features_lr, ratings_lr, test_size=0.2, random_state=42)

    model_lr = LinearRegression()
    model_lr.fit(X_train_lr, y_train_lr)

    return model_lr, X_test_lr, y_test_lr

def predict_linear_regression_rating_attraction(model, user_features):
    predicted_rating_lr = model.predict(user_features)
    return predicted_rating_lr[0]

def train_random_forest_model_attraction():
    features_rf = predict_rating_attraction_df[['Attraction ID', 'User ID', 'Du thuyền 45 phút', 'Nhạc sống', 'Nước đóng chai', 'Trái cây', 'Bảo hiểm', 'Máy hát karaoke', 'Góc selfie', 'Buffet trưa tại nhà hàng', 'Đi cáp treo', 'Đón và trả khách', 'Dịch vụ hướng dẫn', 'Phương tiện đi lại khứ hồi', 'Vé vào các điểm tham quan', 'Lớp học nấu ăn', 'Đầu bếp nói', 'Dịch vụ hướng dẫn bằng tiếng anh', 'Cà phê', 'Thuê xe đạp']]
    ratings_rf = predict_rating_attraction_df['Ratings']

    X_train_rf, X_test_rf, y_train_rf, y_test_rf = train_test_split(features_rf, ratings_rf, test_size=0.2, random_state=42)

    model_rf = RandomForestRegressor(n_estimators=100, random_state=42)
    model_rf.fit(X_train_rf, y_train_rf)

    return model_rf, X_test_rf, y_test_rf

def predict_random_forest_rating_attraction(model, user_features):
    predicted_rating_rf = model.predict(user_features)
    return predicted_rating_rf[0]

def check_model(model, X_test, y_test, model_name):
    # Dự đoán điểm đánh giá trên tập kiểm thử
    predictions = model.predict(X_test)

    # Đánh giá mô hình sử dụng các thang đo
    mse = mean_squared_error(y_test, predictions)
    r2 = r2_score(y_test, predictions) + 1

    # Hiển thị kết quả
    st.write(f"Đánh giá mô hình {model_name}:")
    st.write(f"Mean Squared Error (MSE): {mse}")
    st.write(f"R-squared (R2): {r2}")
    st.write("\n")
