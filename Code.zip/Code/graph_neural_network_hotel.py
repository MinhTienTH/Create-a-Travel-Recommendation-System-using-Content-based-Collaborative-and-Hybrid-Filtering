import networkx as nx
import pandas as pd

def build_graph(data):
    G = nx.Graph()

    for row in data.itertuples(index=False):
        G.add_node(row[0], name=row[1])  # Sử dụng index thay vì cột 'Hotel Name'
        G.add_edge(row[46], row[47], weight=row[8])  # Sửa 'User ID' và 'Hotel ID' tương ứng

    return G

def graph_based_recommendations(G, hotel_name):
    try:
        # Thực hiện Personalized PageRank
        pr = nx.pagerank(G, alpha=0.85, personalization={hotel_id: 1 if name == hotel_name else 0 for hotel_id, name in nx.get_node_attributes(G, 'name').items()})

        # Sắp xếp kết quả theo giảm dần giá trị Personalized PageRank
        recommendations = [hotel_id for hotel_id, _ in sorted(pr.items(), key=lambda x: x[1], reverse=True) if hotel_id != hotel_name]

        return recommendations
    except ZeroDivisionError:
        # Xử lý khi phép chia cho 0 xảy ra
        print("Error: ZeroDivisionError - Alpha cannot be 0 for PageRank.")
        return []